Freebie: Summer And Essentials Icon Set (50 Icons, EPS, PNG, AI)

This freebie has been brought to you by SmashingMagazine.com. 

The icon set was designed by Elena Genova (http://www.mosquitosplace.com/icon-shop) and released exclusively for Smashing Magazine and its readers.

- - - - - - - - - - - - - - - - - -

Dearest Smashing reader,

Thank you for downloading this icon set. You can use them in your commercial as well as your personal works. You may modify the size, color or shape of the icons. No attribution is required. However, reselling of bundles or individual pictograms is prohibited. 

You may make one copy of the assets solely for backup or archival purposes or transfer the assets to a single hard drive, provided that you keep the original and accompanying documentation in your possession. You may enter projects into contests, film festivals, publications and or exhibitions that use the assets in the permitted listed methods.

Furthermore, no claim or action of any sort can arise against the designer in this agreement for the use of these assets and no liability can attach to the designer’s work for any acts, omissions or failures on the part the terms.

The icons may not be resold, sub-licensed, rented, transferred or otherwise made available for use. The icons may not be offered for free downloading from websites other than SmashingMagazine.com.

Please link to the article in which this freebie was released if you would like to spread the word: http://www.smashingmagazine.com/2014/05/27/summer-essentials-icon-set-freebie-eps-png-ai

Sincerely yours,
The Smashing Magazine Team
www.smashingmagazine.com